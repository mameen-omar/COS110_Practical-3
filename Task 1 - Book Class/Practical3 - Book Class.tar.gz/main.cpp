#include <iostream>
#include "book"

using namespace std;

int main()
{
	Book object("FUCK ME!", "MOE CARRIM", "PUSSY696969");

	object.setGenre("FUCK, FUCK, FUck");

	cout << object;

	
	return 0;
}